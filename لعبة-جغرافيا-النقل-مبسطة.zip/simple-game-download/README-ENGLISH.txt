===== Transport Geography Educational Game =====

How to Run the Game (Simple Method):

Method 1 - Standalone File (Easiest):
====================================
1. Find the file "transport-geography-game-standalone.html"
2. Double-click on the file
3. The game will open directly in your browser
4. Enjoy the game!

Method 2 - If Method 1 doesn't work:
===================================
1. Right-click on "transport-geography-game-standalone.html"
2. Select "Open with"
3. Choose your web browser (Chrome, Firefox, Safari, Edge)
4. The game will open directly

Features of this version:
========================
✓ No installation required
✓ Works on all operating systems
✓ Works offline
✓ Contains all features
✓ Arabic interface

Game Content:
============
• 4 educational scenarios
• 5 different transport modes
• Interactive maps
• Tests and simulation
• Comprehensive assessment system

If you face problems:
===================
- Make sure you have a web browser installed
- Try different browsers (Chrome or Firefox recommended)
- Ensure the file is not corrupted

For support: Copy this link for help
===================================
GitHub: https://github.com/transport-geography-game

Created for students of College of International Transport and Logistics
© 2024 Transport Geography Educational Game